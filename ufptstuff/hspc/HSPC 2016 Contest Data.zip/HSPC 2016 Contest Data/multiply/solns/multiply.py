tc = int(raw_input())
while tc:
	tc -= 1
	inp = [int(x) for x in raw_input().split()]
	print inp[0]*inp[1]