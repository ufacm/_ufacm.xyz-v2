import java.util.*;
import java.util.regex.*;

/*
 * This problem can be reduced to finding a cycle in a directed graph. All
 * that we need to do is run Depth-First Search (DFS) from each vertex and see
 * if we can ever reach back to it; if we can, then there is a cycle. If there is no
 * vertex where this is possible, then there are NO cycles.
 *
 * To read input we use regex, the pattern "\d+" works very nicely. You didn't need
 * to use regex to solve this problem, you could've have just manually found all the integers
 * by going through the strings.
 *
 * DIFFICULTY RATING: Mediumish
 */
public class ResearchProblems {
	static final String GOOD = "No problems here, sir";
	static final String BAD = "We have got some problems";
	static Pattern NUMBER = Pattern.compile("\\d+");
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int cases = Integer.parseInt(sc.nextLine());
		while (cases-->0) {
			N = Integer.parseInt(sc.nextLine());
			adjMat = new boolean[N+1][N+1];
			int curPaper = 1;
			String line = "";
			while (!(line = sc.nextLine()).equals("*")) {
				if (line.startsWith((curPaper+1) + ":")) {
					curPaper++;
				}
				Matcher m = NUMBER.matcher(line.substring(line.indexOf(":")+1));
				while (m.find()) {
					String ref = m.group();
					adjMat[curPaper][Integer.parseInt(ref)] = true;
				}
			}
			boolean cycle = false;
			for (int i = 1; i <= N; i++) {
				vis = new boolean[N+1];
				cycle |= hasCycle(i, i);
			}
			if (cycle) System.out.println(BAD);
			else System.out.println(GOOD);
		}
	}

	static int N;
	static boolean[] vis;
	static boolean[][] adjMat;
	// checks if a vertex can reach itself
	static boolean hasCycle(int cur, int reach) {
		vis[cur] = true;
		boolean hasCycle = false;
		for (int i = 1; i <= N; i++) {
			if (adjMat[cur][i]) {
				if (!vis[i]) {
					hasCycle |= hasCycle(i, reach);
				} else {
					if (i == reach) {
						return true;
					}
				}
			}
		}
		return hasCycle;
	}
}