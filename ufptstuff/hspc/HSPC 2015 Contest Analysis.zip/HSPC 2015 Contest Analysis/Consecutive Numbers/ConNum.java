import java.util.*;

/*
 * There are many ways to solve this problem. The most naive way is going through
 * each index and taking K things after it and recording the maximum over all of these.
 * This is a very inefficient way to do it since there's a lot of overlap between consecutive
 * sequences that are next to eachother. Suppose we are given N = [1, 3, 2, 7, 4, 5] and K = 3.
 * Take the sequence of length K starting at 0 and the sequence of length K starting at 1:
 * X = [1, 3, 2] SUM(X) = 6 and Y = [3, 2, 7] SUM(Y) = 12. Notice how SUM(Y) = SUM(X)-N[0]+N[1+K]...we
 * use this fact to solve the problem. We basically just keep sliding a window of length K that
 * starts at the 0 until we can't anymore, continually adding and subtracting the values in order to save time.
 *
 * [1, 3, 2, 7, 4, 5]
 *  |=====| SUM = 6
 *     |=====| SUM = 6 - 1 + 7 = 12
 *        |=====| SUM = 12 - 3 + 4 = 13
 *           |=====| SUM = 13 - 2 + 5 = 16
 *
 * DIFFICULTY RATING: Easy
 */
public class ConNum {

	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		int cases = Integer.parseInt(sc.nextLine());
		while(cases-- > 0) {
			int N = sc.nextInt(), K = sc.nextInt();
			if (K > N) throw new Exception("K > N");
			if (N < 1) throw new Exception("N < 1");
			if (K < 1) throw new Exception("K < 1");
			int max = Integer.MIN_VALUE;
			ArrayDeque<Integer> ad = new ArrayDeque<Integer>();
			int curSum = 0;
			for (int i = 0; i < N; i++) {
				int cur = sc.nextInt();
				if (ad.size() == K) {
					max = Math.max(curSum, max);
					int first = ad.removeFirst();
					curSum -= first;
					curSum += cur;
					ad.add(cur);
					max = Math.max(curSum, max);
				} else {
					ad.add(cur);
					curSum += cur;
				}
			}
			System.out.println(max);
		}
	}
}