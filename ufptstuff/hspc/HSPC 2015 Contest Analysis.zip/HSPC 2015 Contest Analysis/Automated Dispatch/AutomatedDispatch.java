import java.util.*;

/*
 * We just wanted to figure out the number of non-positive IDs given
 * and compare it to K to make sure it was at least that big. Everyone solved
 * this problem during the contest!
 *
 * DIFFICULTY RATING: Easy
 */
public class AutomatedDispatch {
	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		int cases = Integer.parseInt(sc.nextLine());
		while (cases-->0) {
			String[] spl = sc.nextLine().split(" ");
			int N = Integer.parseInt(spl[0]);
			int K = Integer.parseInt(spl[1]);
			if (K > N) throw new Exception("K > N");
			String[] line = sc.nextLine().split(" ");
			if (line.length != N) throw new Exception("Line length not equal to N");
			int cnt = 0;
			for (int i = 0; i < N; i++) {
				int val = Integer.parseInt(line[i]);
				if (val <= 0) {
					cnt++;
				}
			}
			if (cnt >= K) {
				System.out.println("DISPATCH");
			} else {
				System.out.println("WAIT");
			}
		}
	}
}
