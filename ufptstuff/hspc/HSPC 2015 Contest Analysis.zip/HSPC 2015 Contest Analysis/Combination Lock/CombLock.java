import java.util.*;

/*
 * Here we are given a starting position (x1, y1) and an ending position (x2, y2) of a
 * standard combination lock and were asked to find the minimum number of moves to turn
 * the starting configuration to the ending one. Almost all teams solved this problem and there
 * was really nothing more to it than just checking the possible cases of movement: using wrap-around
 * or not using it.
 *
 * DIFFICULTY RATING: Easy
 */
public class CombLock {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int cases = sc.nextInt();
		while (cases-->0) {
			int x1 = sc.nextInt(), y1 = sc.nextInt();
			int x2 = sc.nextInt(), y2 = sc.nextInt();
			System.out.println(dist(x1,x2)+dist(y1,y2));
		}
	}

	static int dist(int x1, int x2) {
		int dist1 = Math.abs(x2-x1); // not wrap around
		int dist2 = x1+Math.abs(9-x2)+1; // wrap x1 down to x2
		int dist3 = x2+Math.abs(9-x1)+1; // wrap x2 down x1
		return Math.min(dist1, Math.min(dist2, dist3));
	}
}
