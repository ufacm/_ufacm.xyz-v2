import java.util.*;

/*
 * 
 *
 * DIFFICULTY RATING: Mediumish
 */
public class Bloxorz {
	
	static char[][] grid; // so ismoveable can access easily
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int cases = Integer.parseInt(sc.nextLine());
		while(cases-->0) {
			String[] spl = sc.nextLine().split(" ");

			int rows = Integer.parseInt(spl[0]);
			int cols = Integer.parseInt(spl[1]);

			//store start and goal positions
			int sX = 0; int sY = 0;
			int gX = 0; int gY = 0;

			//populate grid
			grid = new char[rows][cols];
			for (int i = 0; i < rows; i++) {
				String row = sc.nextLine();
				for (int j = 0; j < cols; j++) {
					grid[i][j] = row.charAt(j);
					if (grid[i][j] == 'S') { sX = i; sY = j; }
					if (grid[i][j] == 'G') { gX = i; gY = j; }
				}
			}

			/* Run breadth-first search (BFS). We could use depth-first search. */
			//we never want to revisit the same state again
			boolean[][][] visited = new boolean[rows][cols][5];
			Queue<State> queue = new LinkedList<State>();

			//setup bfs
			visited[sX][sY][4] = true;
			queue.add(new State(sX, sY, 4));

			boolean won = false;
			while (!queue.isEmpty()) {
				State current = queue.poll(); // dequeue
				int x = current.x;
				int y = current.y;
				int dir = current.dir;

				if (x == gX && y == gY && dir == 4) {
					//we've made it to the goal position and are upright!
					won = true;
					break;
				}

				//we're not quite at the goal yet...Let's try to make every possible move!
				//this is the trickiest part :o

				if (dir == 4) {
					//Imagine this is us before we move:
					//*****
					//*****
					//**X**
					//*****
					//*****


					/* we can roll to the right */
					//*****
					//*****
					//***==
					//*****
					//*****
					if (ismoveable(x, y+1) && ismoveable(x, y+2)) {
						int nextX = x; int nextY = y+1;
						int nextDir = 0; // move to the right
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}


					//roll to the left
					//*****
					//*****
					//==***
					//*****
					//*****
					if (ismoveable(x, y-1) && ismoveable(x, y-2)) {
						int nextX = x; int nextY = y-1;
						int nextDir = 2; // move to the left
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}


					//roll down
					//*****
					//*****
					//*****
					//**|**
					//**|**
					if (ismoveable(x+1, y) && ismoveable(x+2, y)) {
						int nextX = x+1; int nextY = y;
						int nextDir = 3; // move down
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}


					//roll up
					//**|**
					//**|**
					//*****
					//*****
					//*****
					if (ismoveable(x-1, y) && ismoveable(x-2, y)) {
						int nextX = x-1; int nextY = y;
						int nextDir = 1; // move up
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}
				} 
				/* 
				 * for the rest of these we will follow a similar process,
				 * except undocumented 
				*/
				else if (dir == 0) { // right
					if (ismoveable(x+1, y) && ismoveable(x+1, y+1)) {
						int nextX = x+1; int nextY = y;
						int nextDir = 0;
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}

					if (ismoveable(x-1, y) && ismoveable(x-1, y+1)) {
						int nextX = x-1; int nextY = y;
						int nextDir = 0;
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}

					if (ismoveable(x, y+2)) {
						int nextX = x; int nextY = y+2;
						int nextDir = 4;
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}

					if (ismoveable(x, y-1)) {
						int nextX = x; int nextY = y-1;
						int nextDir = 4;
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}
				} else if (dir == 1) { // up
					if (ismoveable(x, y+1) && ismoveable(x-1, y+1)) {
						int nextX = x; int nextY = y+1;
						int nextDir = 1;
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}

					if (ismoveable(x, y-1) && ismoveable(x-1, y-1)) {
						int nextX = x; int nextY = y-1;
						int nextDir = 1;
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}

					if (ismoveable(x+1, y)) {
						int nextX = x+1; int nextY = y;
						int nextDir = 4;
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}

					if (ismoveable(x-2, y)) {
						int nextX = x-2; int nextY = y;
						int nextDir = 4;
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}
				} else if (dir == 2) { // left
					if (ismoveable(x-1, y) && ismoveable(x-1, y-1)) {
						int nextX = x-1; int nextY = y;
						int nextDir = 2;
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}

					if (ismoveable(x+1, y) && ismoveable(x+1, y-1)) {
						int nextX = x+1; int nextY = y;
						int nextDir = 2;
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}

					if (ismoveable(x, y-2)) {
						int nextX = x; int nextY = y-2;
						int nextDir = 4;
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}

					if (ismoveable(x, y+1)) {
						int nextX = x; int nextY = y+1;
						int nextDir = 4;
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}
				} else if (dir == 3) { // down
					if (ismoveable(x, y+1) && ismoveable(x+1, y+1)) {
						int nextX = x; int nextY = y+1;
						int nextDir = 3;
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}

					if (ismoveable(x, y-1) && ismoveable(x+1, y-1)) {
						int nextX = x; int nextY = y-1;
						int nextDir = 3;
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}

					if (ismoveable(x-1, y)) {
						int nextX = x-1; int nextY = y;
						int nextDir = 4;
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}

					if (ismoveable(x+2, y)) {
						int nextX = x+2; int nextY = y;
						int nextDir = 4;
						if (!visited[nextX][nextY][nextDir]) {
							visited[nextX][nextY][nextDir] = true;
							queue.add(new State(nextX, nextY, nextDir));
						}
					}
				}
			}

			if (won) {
				System.out.println("YES");
			} else {
				System.out.println("NO");
			}
		}
	}

	// tells us if we can safely be on a tile
	static boolean ismoveable(int x, int y) {
		// first we must be ON the board!
		if (x < 0 || x >= grid.length || y < 0 || y >= grid[0].length) return false;
		return grid[x][y] == '*' || grid[x][y] == 'S' || grid[x][y] == 'G';
	}
}
class State {
	int x, y;
	int dir;
	//4 is upright, 0 is right, 1 is up, 2 is left, 3 is down
	public State(int x, int y, int dir) {
		this.x = x;
		this.y = y;
		this.dir = dir;
	}

	public String toString() {
		return "(" + x + "," + y + ", DIR:" + dir + ")";
	}
}