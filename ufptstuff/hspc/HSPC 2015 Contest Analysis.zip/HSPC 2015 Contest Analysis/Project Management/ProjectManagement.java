import java.util.*;

/*
 * We've given a set of intervals and want to figure out the most that overlap
 * at any point. The size of the ranges were meant to hint at not using an array
 * to physically record what time was occupied by an interval. The trick for this problem
 * was to treat each endpoint of an interval as a number and then sort them; the criteria for
 * sorting was "first choose lowest time, then break ties based on which was a start/end point having starts
 * come before ends". Then all we had to do was iterate through these endpoints when we hit a start
 * endpoint we increment a counter and when we hit an endpoint we decrement; the counter represents
 * the current number of intervals we're intersecting. We record the maximum the counter ever becomes
 * and that's our answer!
 *
 * DIFFICULTY RATING: Medium
 */
public class ProjectManagement {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int cases = sc.nextInt();
		while (cases-->0) {
			int N = sc.nextInt();
			Endpoint[] endpoints = new Endpoint[2*N];
			int idx = 0;
			for (int i = 0; i < N; i++) {
				endpoints[idx++] = new Endpoint(sc.nextInt(), true);
				endpoints[idx++] = new Endpoint(sc.nextInt(), false);
			}
			Arrays.sort(endpoints);
			int max = 0;
			int current = 0;
			for (Endpoint e : endpoints) {
				if (e.start) {
					// just encountered an interval
					current++;
				} else {
					// just left an interval
					current--;
				}
				max = Math.max(max, current);
			}
			System.out.println(max);
		}
	}
}
class Endpoint implements Comparable<Endpoint> {
	int time;
	boolean start;
	public Endpoint(int time, boolean start) {
		this.time = time;
		this.start = start;
	}
	//we sort by time
	//if two times are the same, we want start points to be first
	public int compareTo(Endpoint other) {
		if (time == other.time) {
			if (start == other.start) return 0;
			if (start) return -1;
			if (other.start) return 1;
			return 0;
		} else {
			return time-other.time;
		}
	}
}