import java.util.*;
import java.lang.*;
import java.io.*;

/*
 * This problem looked very intimidating but was really not. All we had to do
 * was generate every segment and check if it intersected anything after it.
 * The intersection part seemed scary, but notice how all the segments are axis-aligned
 * (either horizontal or vertical). This fact turned out to make the problem much much
 * easier. Details of the actual implementation of the intersection test is found at the 
 * end of the file.
 *
 * DIFFICULTY RATING: Medium
 */
public class RectanglularSpiral
{
	// cool trick for generating the lines
	public static long[] dx = {1, 0, -1, 0};
	public static long[] dy = {0, 1, 0, -1};
	public static void main (String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			String[] dists = br.readLine().split(" ");
			Edge[] edges = new Edge[dists.length];
			long curX = 0;
			long curY = 0;
			//create all the edges
			for(int i = 0; i < dists.length; i++){
				long prevX = curX;
				long prevY = curY;
				curX+=dx[i%4]*Long.parseLong(dists[i]);
				curY+=dy[i%4]*Long.parseLong(dists[i]);
				edges[i] = new Edge(prevX, prevY, curX, curY);
			}
			String ans = "No";
			//see if any intersect
			for(int i = 0 ; i < edges.length; i++){
				//don't check the next edge, it will always intersect the next edge
				for(int j = i + 2; j < edges.length; j++){
					if(edges[i].intersects(edges[j])){
						ans = "Yes";
						break;
					}
				}
				if(ans.equals("Yes")){
					break;
				}
			}
			System.out.println(ans);
		}
	}
}
class Edge{
	long x1, y1, x2, y2;
	public Edge(long x1, long y1, long x2, long y2){
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
	}
	public boolean intersects(Edge o){
		boolean yWorks = false;
		boolean xWorks = false;
		if(Math.max(y1, y2) > Math.max(o.y1, o.y2)){
			long lowY = Math.min(y1, y2);
			if(Math.max(o.y1, o.y2)>=lowY){
				yWorks = true;
			}
		} else {
			long lowY = Math.min(o.y1, o.y2);
			if(Math.max(y1, y2)>=lowY){
				yWorks = true;
			}
		}
		if(Math.max(x1, x2) > Math.max(o.x1, o.x2)){
			long lowX = Math.min(x1, x2);
			if(Math.max(o.x1, o.x2)>=lowX){
				xWorks = true;
			}
		} else {
			long lowX = Math.min(o.x1, o.x2);
			if(Math.max(x1, x2)>=lowX){
				xWorks = true;
			}
		}
		return xWorks && yWorks;
	}
}