import java.util.*;

/*
 * This was a really tricky problem. No formula exists to count simple polygons just based on
 * the size of the point set: it's easy to convince yourself by coming up with a point set rather
 * than using the sample one provided. The idea was to actually generate every polygon (the
 * big hint here being that there were at most 9 points) and check if it was simple. To do this
 * we found every subset of points that had at least 3 points (you need at least 3 to make a polygon!)
 * and then for each subset found every simple polygon that used ALL points in it. Since every polygon
 * is a sequence of vertices, all we had to do was find every *circular* permutation of each subset.
 *
 * To check that a polygo was simple we went through each edge and made sure it did not intersect any
 * non-adjacent edges. You could have used Java's Line2D class for this, but in the solution presented
 * here we use the Counter-Clockwise test (CCW) and manually checked for intersections.
 *
 * We end up counting each simple polygon twice since a simple polygon can be described with exactly
 * two permutations (they're the reverse of eachother) and so we divide by two and that's our answer.
 *
 * Slight technicality: The area calculation is not required (its an artifact from the original problem statement)
 * because vertices are not allowed to be collinear.
 *
 * Another cool problem: How many convex polygons exist on N points? Consider the two cases of whether we allow
 * collinear vertices or not. Does a mathematical formula exists in either case?
 *
 * DIFFICULTY RATING: Very hard
 */
public class SimplePolygons {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int cases = sc.nextInt();
		while(cases-- > 0) {
			int N = sc.nextInt();
			Point[] ptz = new Point[N];
			for (int i = 0; i < N; i++) ptz[i] = new Point(sc.nextInt(), sc.nextInt());
			int cnt = 0;
			for (int x = 0; x < (1 << N); x++) {
				int amt = 0;
				for (int j = 0; j < N; j++) {
					if ((x & (1 << j)) != 0) amt++;
				}
				if (amt < 3) continue;
				int[] used = new int[amt];
				int[] array = new int[amt-1];
				amt = 0;
				for (int j = 0; j < N; j++) {
					if ((x & (1 << j)) != 0) used[amt++] = j;
				}
				//now permute 0, 1, ..., (amt - 1)
				for (int j = 0; j < array.length; j++) array[j] = j;
				do {
					Point[] p = new Point[used.length];
					p[0] = ptz[used[0]];
					for (int j = 0; j < array.length; j++) {
						p[j+1] = ptz[used[array[j]+1]];
					}
					boolean intersect = false;
					for (int i = 1; i < p.length; i++) {
						//Seg:
						Point p1 = p[i-1]; Point p2 = p[i];
						//which segments can (p1, p2) intersect?
						for (int j = 1; j < i-1; j++) {
							Point q1 = p[j-1]; Point q2 = p[j];
							//Do they intersect?
							if (intersect(p1, p2, q1, q2)) {
								intersect = true;
							}
						}
					}
					//check if p[used.length-1] -> p[0] intersects anything:
					for (int j = 2; j < p.length-1; j++) {
						if (intersect(p[p.length-1], p[0], p[j-1], p[j])) {
							intersect = true;
						}
					}
					//bad case when polygon is a line!
					if (!intersect && area(p) != 0.0) {
						cnt++;
					}
				} while (nextPermutation(array));
			}
			System.out.println(cnt/2);//we overcount by double
		}
	}

	static double area(Point[] ptz) {
		double area = 0.0;
		int m = ptz.length;
		for (int i = 0; i < m; i++) {
			area += ptz[i].x*ptz[(i+1)%m].y;
			area -= ptz[i].y*ptz[(i+1)%m].x;
		}
		return area/2;
	}

	static boolean intersect(Point p1, Point p2, Point q1, Point q2) {
		long xx = p2.x-p1.x; long yy = p2.y-p1.y;
		long x2 = q1.x-p2.x; long y2 = q1.y-p2.y;
		long x3 = q2.x-p2.x; long y3 = q2.y-p2.y;
		long xxx = q2.x-q1.x; long yyy = q2.y-q1.y;
		long xx2 = p1.x-q2.x; long yy2 = p1.y-q2.y;
		long xx3 = p2.x-q2.x; long yy3 = p2.y-q2.y;
		long c1 = cross(xx, yy, x2, y2);
		long c2 = cross(xx, yy, x3, y3);
		long c3 = cross(xxx, yyy, xx2, yy2);
		long c4 = cross(xxx, yyy, xx3, yy3);
		return opp(c1, c2) && opp(c3, c4);
	}

	static boolean opp(long c1, long c2) {
		return c1*c2 <= 0;
	}

	static long cross(long x, long y, long x1, long y1) {
		//|e1 e2 e3 |
		//|x  y  0  |
		//|x1 y1 0  |
		long val = x*y1-y*x1;
		if (val < 0) return -1;
		else if (val == 0) return 0;
		else return 1;

	}

	static boolean nextPermutation(int[] arr) {
		int n = arr.length;
		int i = n - 2;
		while (i >= 0 && arr[i] >= arr[i + 1]) i--;
		if(i < 0) return false;
		int j = n - 1;
		while (arr[i] >= arr[j]) j--;
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
		Arrays.sort(arr, i + 1, n);		
		return true;
	}
}
class Point {
	public long x, y;
	public Point(long x, long y) {
		this.x = x;
		this.y = y;
	}
	public String toString() {
		return "(" + x + "," + y + ")";
	}
}