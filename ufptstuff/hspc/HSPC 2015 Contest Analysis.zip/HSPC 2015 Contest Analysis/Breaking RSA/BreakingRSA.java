import java.util.*;

/*
 * In this problem we're given a number N that is the product of two prime numbers p
 * and q. The goal is to recover p and q. The naive way of going through every pair
 * of prime numbers was too slow for this. You could do this with one for loop, testing
 * if the number was prime and if it divided out of N; if it did you got N/p and made sure
 * that was prime; if it is, then that's your answer!
 *
 * It turns out you don't even have an isPrime method, but that requires some more insight
 * and so we omitted that from the solution.
 *
 * DIFFICULTY RATING: Easy
 */
public class BreakingRSA {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int cases = sc.nextInt();
		while (cases-- > 0) {
			int modulus = sc.nextInt();
			for (int p = 2; p < modulus; p++) {
				if ( (modulus % p == 0) && isPrime(p) ) {
					int q = modulus/p;
					if (isPrime(q)) {
						System.out.println(Math.min(p, q) + " " + Math.max(p, q));
						break;
					}
				}
			}
		}
	}

	static boolean isPrime(int x) {
		if (x == 0 || x == 1) return false;
		if (x == 2) return true;
		for (int i = 2; i < x; i++) {
			if (x % i == 0) return false;
		}
		return true;
	}
}
