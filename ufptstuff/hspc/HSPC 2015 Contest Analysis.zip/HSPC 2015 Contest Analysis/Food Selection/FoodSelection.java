import java.util.*;

/*
 * This problem is 0-1 Knapsack with a slight twist since items can be 'upgraded'.
 * This required a dynamic programming solution, but knowledge of it isn't entirely necessary.
 * Essentially we solve this recursively and cache results that we've solved (using the memo array)
 * so we don't have to recompute anything; this makes the runtime of the recursive solution 
 * MUCH better. The bulk of this solution is in the recursive function and it works as follows:
 * "best_cost(item_idx, budget_left)" returns the maximum amount of food we can get using the 
 * the remaining budget budget_left using only items from item_idx and on. The base cases are
 * when we either run out of items to purchase or when our budget is 0. We have three options for
 * a given set of parameters: don't take the item, take the item (if it fits in the budget), or take
 * the upgraded version of that item (if it exists and fits in budget).
 *
 * DIFFICULTY RATING: Hard (2nd hardest problem in the set)
 */
public class FoodSelection {

	static Item[] items;
	static Integer[][] memo;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int cases = Integer.parseInt(sc.nextLine());
		while (cases-->0) {
			String[] spl = sc.nextLine().split(" ");
			int N = Integer.parseInt(spl[0]);
			int K = Integer.parseInt(spl[1]);
			items = new Item[N];
			for (int i = 0; i < N; i++) {
				spl = sc.nextLine().split(" ");
				if (spl.length == 4) {
					items[i] = new Item(Integer.parseInt(spl[0]), Integer.parseInt(spl[1]),
										Integer.parseInt(spl[2]), Integer.parseInt(spl[3]));
				} else {
					items[i] = new Item(Integer.parseInt(spl[0]), Integer.parseInt(spl[1]));
				}
			}
			memo = new Integer[N][K+1];
			System.out.println(best_cost(0, K));

		}
	}

	static int best_cost(int item_idx, int budget_left) {
		if (item_idx >= items.length) return 0;
		if (budget_left == 0) return 0;
		if (memo[item_idx][budget_left] != null) return memo[item_idx][budget_left];

		int best = best_cost(item_idx+1, budget_left); // don't take item
		if (items[item_idx].cost <= budget_left) {
			best = Math.max(best, 
				best_cost(item_idx+1, budget_left-items[item_idx].cost)
				+ items[item_idx].amount);
		}

		if ((items[item_idx].cost+items[item_idx].altcost) <= budget_left) {
			best = Math.max(best,
				best_cost(item_idx+1, budget_left-items[item_idx].cost-items[item_idx].altcost)
				+ items[item_idx].amount+items[item_idx].altamount);
		}

		return memo[item_idx][budget_left]=best;
	}
}
class Item {
	public int cost, amount;
	public int altcost, altamount;
	public Item(int cost, int amount) {
		this.cost = cost;
		this.amount = amount;
	}
	public Item(int cost, int amount, int altcost, int altamount) {
		this.cost = cost;
		this.amount = amount;
		this.altcost = altcost;
		this.altamount = altamount;
	}
	public String toString() {
		return cost + " " + amount + " " + altcost + " " + altamount;
	}
}