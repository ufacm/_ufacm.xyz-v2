// code by Alex Anderson, 2/9/14
import java.util.*;

public class ChairFilling {
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    int t = in.nextInt();
    while (t-->0) {
      int people = in.nextInt();
      int chairs = in.nextInt();
      int result = Math.max(people - chairs, 0);
      System.out.println(result);
    }
  }
}