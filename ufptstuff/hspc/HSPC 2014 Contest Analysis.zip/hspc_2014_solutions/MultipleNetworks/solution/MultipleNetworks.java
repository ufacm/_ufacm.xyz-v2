// code by Alex Anderson 2/9/14
import java.util.*;

public class MultipleNetworks {
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    int t = in.nextInt();
    while (t-->0) {
      int numNodes = in.nextInt();
      ArrayList<ArrayList<Integer>> graph = new ArrayList<ArrayList<Integer>>();
      for (int i = 0; i <= numNodes; ++i)
        graph.add(new ArrayList<Integer>());
        
      for (int i = 1; i <= numNodes; ++i) {
        int k = in.nextInt();
        HashSet<Integer> set = new HashSet<Integer>(k*5);
        for (int j = 0; j < k; ++j) {
          int id = in.nextInt();
          if (id == i)
            continue; // ignore the id that matches to itself
          set.add(id);
        }
        Iterator<Integer> iter = set.iterator();
        while (iter.hasNext())  {
          int id = iter.next();
          graph.get(i).add(id);
          graph.get(id).add(i);
        }
      }
      
      boolean[] visited = new boolean[numNodes+1];
      int numComponents = 0;
      for (int i = 1; i < visited.length; ++i) {
        if (visited[i])
          continue;
        ++numComponents;
        Queue<Integer> queue = new LinkedList<Integer>();
        queue.offer(i);
        while (!queue.isEmpty()) {
          int cur = queue.poll();
          ArrayList<Integer> neighbors = graph.get(cur);
          for (int j = 0; j < neighbors.size(); ++j) {
            int next = neighbors.get(j);
            if (visited[next])
              continue;
            visited[next] = true;
            queue.add(next);
          }
        }
      }
      System.out.println(numComponents);
    }
  }
}