// Original Code by Alex Anderson, 1/19/14

import java.util.*;

public class CallingDrivers {
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    int t = in.nextInt(); // number of test cases to follow
    while (t-->0) {
      int n = in.nextInt(); // number of stranded people
      int m = in.nextInt(); // number of helpful people with cars
      
      Car[] cars = new Car[m];
      for (int i = 0; i < m; ++i) {
        int time = in.nextInt();
        int space = in.nextInt();
        cars[i] = new Car(time, space);
      }
      
      // sort cars so that the cars which arrive first come first in the list
      Arrays.sort(cars);
      int totalSpaceUsed = 0;
      int finishTime = -1;
      
      // count how many people can be collected by the time the Ith car arrives.
      // stop once we've collected everyone
      for (int i = 0; i < m; ++i) {
        totalSpaceUsed += cars[i].space;
        finishTime = cars[i].time;
        if (totalSpaceUsed >= n)
          break;
      }
      
      System.out.println(finishTime);
    }
  }
}

class Car implements Comparable<Car> {
  int time;
  int space;
  
  public Car(int time, int space) {
    this.time = time;
    this.space = space;
  }
  
  public int compareTo(Car c) {
    return time - c.time;
  }
}