// Author - Baker Bokorney
import java.util.*;

class PartyPoopersBaker {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int T = in.nextInt();
		while(T-- > 0) {
			int N = in.nextInt();
			int M = in.nextInt();
			HashMap<String, Boolean> going = new HashMap<String, Boolean>();
			HashMap<String, ArrayList<String>> dependents = new HashMap<String, ArrayList<String>>();
			for(int i = 0; i < N; ++i) {
				String name = in.next();
				String decision = in.next();
				ArrayList<String> deps = new ArrayList<String>();
				if(decision.equals("g")) {
					going.put(name, true);
				}
				else if(decision.equals("n")) {
					going.put(name, false);
				}
				else {
					int D = in.nextInt();
					for(int k = 0; k < D; ++k) {
						deps.add(in.next());
					}
				}
				dependents.put(name, deps);
			}

			for(String name : dependents.keySet()) {
				attending(name, going, dependents);
			}

			int numAttending = 0;
			for(String name : dependents.keySet()) {
				if(going.get(name)) {
					++numAttending;
				}
			}

			if(numAttending >= M) {
				System.out.println("YES");
			}
			else {
				System.out.println("NO");
			}

		}
	}

	private static boolean attending(String name, HashMap<String, Boolean> going, HashMap<String, ArrayList<String>> dependents) {
		if(going.containsKey(name)) {
			return going.get(name);
		}

		for(String dependent : dependents.get(name)) {
			if(!attending(dependent, going, dependents)) {
				going.put(name, false);
				return false;
			}
		}
		going.put(name, true);
		return true;
	}
}