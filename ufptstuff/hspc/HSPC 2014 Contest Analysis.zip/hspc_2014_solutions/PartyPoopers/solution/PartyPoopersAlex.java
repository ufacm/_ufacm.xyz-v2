// solution by Alex Anderson, 2/10/14
import java.util.*;

public class PartyPoopersAlex {
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    int t = in.nextInt();
    while (t-->0) {
      int teamSize = in.nextInt();
      int minPartySize = in.nextInt();
      
      int partySize = 0;
      HashMap<String, Integer> nameToInt = new HashMap<>();
      String[][] input = new String[teamSize][];
      int[] inDegree = new int[teamSize];
      Queue<Integer> newlyGoingMembers = new LinkedList<Integer>();
      ArrayList<ArrayList<Integer>> graph = new ArrayList<>();
      for (int i = 0; i < teamSize; ++i)
        graph.add(new ArrayList<Integer>());
      
      in.nextLine();
      for (int i = 0; i < teamSize; ++i) {
        input[i] = (in.nextLine()).split(" ");
        nameToInt.put(input[i][0], i);
      }
      for (int i = 0; i < teamSize; ++i) {
        char c = input[i][1].charAt(0);
        if (c == 'u') {
          int len = Integer.parseInt(input[i][2]);
          inDegree[i] = len;
          for (int j = 3; j < 3+len; ++j) {
            int id = nameToInt.get(input[i][j]);
            graph.get(id).add(i); // current member depends on member ID
          }
        } else if (c == 'g') {
          newlyGoingMembers.offer(i);
          ++partySize;
        }
      }
      
      while (!newlyGoingMembers.isEmpty() && partySize < minPartySize) {
        int newGuy = newlyGoingMembers.poll();
        ArrayList<Integer> dependencies = graph.get(newGuy);
        for (int i = 0; i < dependencies.size(); ++i) {
          int otherGal = dependencies.get(i);
          inDegree[otherGal]--;
          if (inDegree[otherGal] == 0) {
            newlyGoingMembers.add(otherGal);
            ++partySize;
          }
        }
      }
      
      if (partySize >= minPartySize)
        System.out.println("YES");
      else
        System.out.println("NO");
    }
  }
}
