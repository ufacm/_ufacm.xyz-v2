// code by Alex Anderson, 2/25/14
import java.util.*;

public class Weight {

  public static final int MAX_SIZE = 200*500/2;

  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    int t = in.nextInt();
    while (t-->0) {
      int n = in.nextInt();
      boolean[] possible = new boolean[MAX_SIZE + 1];
      possible[0] = true;
      int sumSoFar = 0;
      for (int i = 0; i < n; ++i) {
        int item = in.nextInt();
        int start = Math.min(sumSoFar, MAX_SIZE) - item;
        for (int j = start; j >= 0; --j) {
          if (possible[j]) {
            possible[j+item] = true;
          }
        }
        sumSoFar += item;
      }
      if (sumSoFar % 2 == 0 && possible[sumSoFar/2])
        System.out.println("YES");
      else
        System.out.println("NO");
    }
  }
}


