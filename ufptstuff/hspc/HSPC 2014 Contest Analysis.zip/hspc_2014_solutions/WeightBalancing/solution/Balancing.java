import java.util.*;
//joshua kirstein
public class Balancing {

  //topdown version of prob K
	static int[][] memo;
	static int[] weights;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int cases = sc.nextInt();
		for (int i = 0; i < cases; i++) {
			int N = sc.nextInt();
			weights = new int[N];
			int sum = 0;
			for (int j = 0; j < N; j++) { 
				weights[j] = sc.nextInt();
				sum += weights[j];
			}
			if (sum % 2 != 0) {
				System.out.println("NO");
			} else {
				int goal = sum/2;
				memo = new int[sum+1][weights.length];
				if (can(goal, 0)) {
					System.out.println("YES");
				} else {
					System.out.println("NO");
				}
			}
		}

	
	}

	public static boolean can(int sum, int idx) {
		if (sum == 0) return true;
		if (sum < 0) return false;
		if (idx >= weights.length) return false;
		if (memo[sum][idx] != 0) return memo[sum][idx] == 1;
		boolean william = can(sum, idx+1) || can(sum-weights[idx], idx+1);
		memo[sum][idx] = william ? 1 : 2;
		return william;
	}

}
