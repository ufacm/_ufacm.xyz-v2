// code by Alex Anderson, 2/9/14
import java.util.*;

public class GCD {
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    int t = in.nextInt();
    while (t-->0) {
      int n = in.nextInt();
      int gcd = in.nextInt();
      while (n-->1) {
        gcd = gcd(gcd, in.nextInt());
      }
      System.out.println(gcd);
    }
  }
  
  public static int gcd(int a, int b) {
    if (b == 0)
      return a;
    return gcd(b, a % b);
  }
}