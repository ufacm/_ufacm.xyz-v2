import java.util.*;

public class SquareDarts {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int[] regions = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
		int[] scores = {10, 9 ,8, 7, 6, 5, 4, 3, 2, 1};
		int score, 
			x, 
			y, 
			xregion = -1, 
			yregion = -1;

		for (int player = 0; player < n; player++) {
			score = 0;
			for (int dartThrow = 0; dartThrow < 10; dartThrow++) {
				x = input.nextInt();
				y = input.nextInt();

				// check the region x falls in
				for (int i = 0; i < regions.length; i++) {
					if (-regions[i] <= x && x <= regions[i]) {
						xregion = i;
						//System.out.println("xregion: " + i);
						break;
					}
				}

				// check the region y falls in
				for (int i = 0; i < regions.length; i++) {
					if (-regions[i] <= y && y <= regions[i]) {
						yregion = i;
						//System.out.println("yregion: " + i);
						break;
					}
				}

				// alternatively, use ternary conditional statement here
				if (xregion > yregion) {
					score += scores[xregion];
					//System.err.println("score: " + scores[xregion]);
				} else {
					score += scores[yregion];
					//System.err.println("score: " + scores[yregion]);
				}
			}
			System.out.println(score);
		}
	}
}
