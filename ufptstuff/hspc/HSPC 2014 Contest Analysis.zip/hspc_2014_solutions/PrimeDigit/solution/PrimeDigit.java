import java.util.*;

public class PrimeDigit {

  static HashMap<Character, Integer> map;
  static char[] reverseMap = {'0', '2', '3', '5', '7'};

  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    
    map = new HashMap<Character, Integer>();
    map.put('0', 0);
    map.put('2', 1);
    map.put('3', 2);
    map.put('5', 3);
    map.put('7', 4);
    
    int t = in.nextInt();
    while (t-->0) {
      String cmd = in.next();
      String first = in.next();
      String second = in.next();
      long firstNum = convertFromPrimeDigit(first);
      long secondNum = convertFromPrimeDigit(second);
      
      long ans = 0;
      
      switch(cmd.charAt(0)) {
        case 'A':
          ans = firstNum + secondNum;
          break;
        case 'S':
          ans = firstNum - secondNum;
          break;
        case 'M':
          ans = firstNum * secondNum;
          break;
        case 'D':
          ans = firstNum / secondNum;
          break;
      }
      
      String result = convertToPrimeDigit(ans);
      System.out.println(result);
    }
  }
  
  public static void validate() {
    for (int i = -100; i <= 100; ++i) {
      System.out.printf("%d = %s = %d\n", i, convertToPrimeDigit(i), convertFromPrimeDigit(convertToPrimeDigit(i)));
    }
  }
  
  public static String convertToPrimeDigit(long ans) {
    String ret = "";
    boolean neg = false;
    if (ans < 0) {
      ans = -ans;
      neg = true;
    }
    
    while (ans >= 5) {
      int temp = (int)(ans % 5);
      ret = reverseMap[temp] + ret;
      ans /= 5;
    }
    ret = reverseMap[(int)ans] + ret;
    return (neg ? "-" : "") + ret;
  }
  
  public static long convertFromPrimeDigit(String num) {
    long ret = 0;
    int idx = 0;
    boolean neg = false;
    if (num.charAt(idx) == '-') {
      neg = true;
      ++idx;
    }
    
    for (; idx < num.length(); ++idx) {
      int val = map.get(num.charAt(idx));
      ret *= 5;
      ret += val;
    }
    
    if (neg)
      ret = -ret;
    
    return ret;
  }
}
