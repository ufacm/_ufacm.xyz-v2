Each of the directories will correspond to a problem in the set given at HSPC 2014

Each directory has two subdirectories:
	io - the input file and output file for the problem
	solution - the solution in a .java file