// solution by Alex Anderson 2/12/14
import java.util.*;

public class Seating {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int t = in.nextInt();
		while (t-->0) {
			int teamSize = in.nextInt();
			boolean canDo = true;
			byte[] degree = new byte[teamSize+1];
      int[][] data = new int[teamSize+1][];
			for (int i = 1; i <= teamSize; ++i) {
				int k = in.nextInt();
				int[] temp = new int[k];
        data[i] = temp;
				for (int j = 0; j < k; ++j) {
					temp[j] = in.nextInt();
					if (!canDo)
						continue;
					degree[i]++;
					degree[temp[j]]++;
          // check current data
          boolean badMatch = false;
					for (int m = 0; m < j; ++m) {
						if (temp[j] == temp[m]) {
              badMatch = true;
							break;
						}
					}
          // check other data
          if (data[temp[j]] != null) {
            for (int m = 0; m < data[temp[j]].length; ++m) {
              if (data[temp[j]][m] == i) {
                badMatch = true;
                break;
              }
            }
          }
          if (badMatch) {
            degree[i]--;
            degree[temp[j]]--;
          }
          
					if (degree[i] == 4 || degree[temp[j]] == 4)
						canDo = false;
				}
			}
			if (canDo)
				System.out.println("YES");
			else
				System.out.println("NO");
		}
	}
}