// Code by Alex Anderson, 2/9/14

import java.util.*;

public class CaesarCipher {
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    int tests = in.nextInt();
    while (tests-->0) {
      int shiftAmount = in.nextInt();
      /* Below, we are modding, adding, and modding again.  Why? Because if shiftAmount is a negative value, the modulus
       will return a negative value between -25 and 0.  We don't want that, so we add 26 to force it nonnegative.
       But if it was already positive, then its too big again, so we mod by 26 to fix that. */
      int letterShift = ((shiftAmount % 26) + 26) % 26;
      int numberShift = ((shiftAmount % 10) + 10) % 10;
      char[] input = (in.next()).toCharArray();
      for (int i = 0; i < input.length; ++i) {
        char c = input[i];
        // Characters have ASCII values.  We can check if a char is a letter or number like this.
        // Alternatively, you can use the Character class's API: Character.isLowerCase(c), Character.isDigit(c)
        if (c >= 'a' && c <= 'z') {
          if (c + letterShift <= 'z') {
            input[i] = (char)(c + letterShift);
          } else {
            input[i] = (char)(c + letterShift - 26);
          }
        } else { // we don't need to test if it is a number because the only options are letters and numbers
          if (c + numberShift <= '9') {
            input[i] = (char)(c + numberShift);
          } else {
            input[i] = (char)(c + numberShift - 10);
          }
        }
      }
      System.out.println(new String(input));
    }
  }
}
