import java.util.*;

public class WorkSplitter {
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    int numDays = in.nextInt();
    while (numDays-->0) {
      int numTasks = in.nextInt();
      int numEmployees = in.nextInt();
      int[] taskMinutes = new int[numTasks];
      for (int i = 0; i < numTasks; ++i) {
        taskMinutes[i] = in.nextInt();
      }
      long start = System.currentTimeMillis();
      int minSplit = assign(taskMinutes, numEmployees);
      System.out.println(minSplit);
      //System.out.printf("%d  (%d ms)\n", minSplit, System.currentTimeMillis() - start);
      
      // if Q2
      // if (minSplit > 480)
      //   System.out.println("NO");
      // else
      //   System.out.println("YES");
    }
  }
  
  // brute force.
  public static int assign(int[] taskMinutes, int numEmployees) {
    int[] assignment = new int[taskMinutes.length];
    int[] tempSum = new int[numEmployees];
    int tempMax;
    int minResult = Integer.MAX_VALUE;
    do {
      Arrays.fill(tempSum, 0);
      tempMax = 0;
      for (int i = 0; i < assignment.length; ++i) {
        tempSum[assignment[i]] += taskMinutes[i];
      }
      for (int i = 0; i < tempSum.length; ++i) {
        tempMax = Math.max(tempMax, tempSum[i]);
      }
      minResult = Math.min(minResult, tempMax);
    } while (hasNext(assignment, numEmployees));
    return minResult;
  }
  
  public static boolean hasNext(int[] assignment, int numEmployees) {
    int sum = 0;
    for (int i = 0; i < assignment.length; ++i)
      sum += assignment[i];
    if (sum == assignment.length * (numEmployees-1))
      return false;
    
    assignment[0] += 1;
    int idx = 0;
    while (idx < assignment.length && assignment[idx] == numEmployees) {
      assignment[idx] = 0;
      assignment[idx+1] += 1;
      ++idx;
    }
    return true;
  }
}